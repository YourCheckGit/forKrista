package org.example;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.poi.sl.usermodel.Background;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.usermodel.Date1904Support;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.*;

import static java.lang.Math.max;
import static java.lang.Math.min;

public class Group {
    public static void main(String[] args) throws IOException {
        Group group = new Group();
        group.createGroupedTable();
    }
    ArrayList<Integer> KIndexes = new ArrayList<>();
    ArrayList<Integer> SumIndexes = new ArrayList<>();
    ArrayList<Integer> MinIndexes = new ArrayList<>();
    ArrayList<Integer> MaxIndexes = new ArrayList<>();
    ArrayList<Integer> ConcIndexes = new ArrayList<>();
    XSSFWorkbook book = new XSSFWorkbook(new FileInputStream("table.xlsx"));
    XSSFSheet sheet = book.getSheetAt(0);
    XSSFWorkbook resBook = new XSSFWorkbook();
    XSSFSheet resSheet = resBook.createSheet("result");
    XSSFRow resRow = resSheet.createRow(0);
    public Group() throws IOException {
    }
    public void createGroupedTable() throws IOException {
        getIndexes(); //нужные индексы получены, заголовок готов
        ArrayList<XSSFRow> usedRows = new ArrayList<>();
        int rowIndex = 1;
        int resRowIndex = 1;
        XSSFRow row = sheet.getRow(rowIndex);
        while(row != null) {
            if(!usedRows.contains(row)) {
                usedRows.add(row);
                resRow = resSheet.createRow(resRowIndex);//создаем результирующую строку
                ArrayList<Integer> cloneKIndexes = (ArrayList<Integer>) KIndexes.clone(); //делаем клоны массивов
                ArrayList<Integer> cloneSumIndexes = (ArrayList<Integer>) SumIndexes.clone();
                ArrayList<Integer> cloneMinIndexes = (ArrayList<Integer>) MinIndexes.clone();
                ArrayList<Integer> cloneMaxIndexes = (ArrayList<Integer>) MaxIndexes.clone();
                ArrayList<Integer> cloneConcIndexes = (ArrayList<Integer>) ConcIndexes.clone();
                int resCellIndex = 0;//индекс для перемещения по заголовку
                XSSFCell headCell = resSheet.getRow(0).getCell(resCellIndex);
                while (headCell != null) {//заполняем новую строку
                    switch (headCell.getStringCellValue()) {
                        case "K":
                            resRow.createCell(resCellIndex);
                            resRow.getCell(resCellIndex).setCellValue(row.getCell(cloneKIndexes.getFirst()).getNumericCellValue());
                            cloneKIndexes.removeFirst();
                            break;
                        case "SUM":
                            resRow.createCell(resCellIndex);
                            resRow.getCell(resCellIndex).setCellValue(row.getCell(cloneSumIndexes.getFirst()).getNumericCellValue());
                            cloneSumIndexes.removeFirst();
                            break;
                        case "MIN":
                            resRow.createCell(resCellIndex);
                            resRow.getCell(resCellIndex).setCellValue(row.getCell(cloneMinIndexes.getFirst()).getNumericCellValue());
                            cloneMinIndexes.removeFirst();
                            break;
                        case "MAX":
                            resRow.createCell(resCellIndex);
                            resRow.getCell(resCellIndex).setCellValue(row.getCell(cloneMaxIndexes.getFirst()).getNumericCellValue());
                            cloneMaxIndexes.removeFirst();
                            break;
                        case "CONC":
                            resRow.createCell(resCellIndex);
                            resRow.getCell(resCellIndex).setCellValue(row.getCell(cloneConcIndexes.getFirst()).getNumericCellValue());
                            cloneConcIndexes.removeFirst();
                            break;
                    }
                    resCellIndex++;
                    headCell = resSheet.getRow(0).getCell(resCellIndex);
                }
                resCellIndex = 0;
                int compareRowIndex = rowIndex+1;
                XSSFRow compareRow = sheet.getRow(compareRowIndex);
                while (compareRow != null){
                    boolean isEqual = true;
                    for(int index : KIndexes){
                        if(row.getCell(index).getNumericCellValue() != compareRow.getCell(index).getNumericCellValue()){
                            isEqual = false;
                        }
                    }
                    if(isEqual){
                        usedRows.add(compareRow);
                        headCell = resSheet.getRow(0).getCell(resCellIndex);
                        cloneSumIndexes = (ArrayList<Integer>) SumIndexes.clone();
                        cloneMinIndexes = (ArrayList<Integer>) MinIndexes.clone();
                        cloneMaxIndexes = (ArrayList<Integer>) MaxIndexes.clone();
                        cloneConcIndexes = (ArrayList<Integer>) ConcIndexes.clone();
                        while (headCell != null) {
                            double oldValue;
                            switch (headCell.getStringCellValue()) {
                                case "SUM":
                                    oldValue = resRow.getCell(resCellIndex).getNumericCellValue();
                                    resRow.getCell(resCellIndex).setCellValue(oldValue + compareRow.getCell(cloneSumIndexes.getFirst()).getNumericCellValue());
                                    cloneSumIndexes.removeFirst();
                                    break;
                                case "MIN":
                                    oldValue = resRow.getCell(resCellIndex).getNumericCellValue();
                                    resRow.getCell(resCellIndex).setCellValue(min(oldValue, compareRow.getCell(cloneMinIndexes.getFirst()).getNumericCellValue()));
                                    cloneMinIndexes.removeFirst();
                                    break;
                                case "MAX":
                                    oldValue = resRow.getCell(resCellIndex).getNumericCellValue();
                                    resRow.getCell(resCellIndex).setCellValue(max(oldValue, compareRow.getCell(cloneMaxIndexes.getFirst()).getNumericCellValue()));
                                    cloneMaxIndexes.removeFirst();
                                    break;
                                case "CONC":
                                    int numb1 = (int)Math.round(resRow.getCell(resCellIndex).getNumericCellValue());
                                    int numb2 = (int)Math.round(compareRow.getCell(cloneConcIndexes.getFirst()).getNumericCellValue());
                                    String conc = String.valueOf(numb1) + String.valueOf(numb2);
                                    resRow.getCell(resCellIndex).setCellValue(conc);
                                    cloneConcIndexes.removeFirst();
                                    break;
                            }
                            headCell = resSheet.getRow(0).getCell(++resCellIndex);
                        }
                    }
                    compareRow = sheet.getRow(++compareRowIndex);
                }
                resRow = sheet.getRow(++resRowIndex);
            }
            row = sheet.getRow(++rowIndex);
        }
        resBook.write(new FileOutputStream("resultTable.xlsx"));
        resBook.close();
    }
    public void getIndexes(){ //получаю индексы нужных колонок, одновременно заполняя заголовок результирующей таблицы
        XSSFRow row = sheet.getRow(0);
        int cellIndex = 0;
        int resCellIndex = 0;
        XSSFCell cell = row.getCell(cellIndex);
        Cell resCell;
        CellStyle cellStyle = resBook.createCellStyle();
        cellStyle.setAlignment(HorizontalAlignment.CENTER);
        BorderStyle bs = BorderStyle.THIN;
        cellStyle.setBorderBottom(bs);
        cellStyle.setBorderRight(bs);
        while(cell != null){
            switch (cell.getStringCellValue()) {
                case "K":
                    KIndexes.add(cellIndex);
                    resCell = resRow.createCell(resCellIndex);
                    resCell.setCellValue("K");
                    resCell.setCellStyle(cellStyle);
                    resCellIndex++;
                    break;
                case "SUM":
                    SumIndexes.add(cellIndex);
                    resCell = resRow.createCell(resCellIndex);
                    resCell.setCellValue("SUM");
                    resCell.setCellStyle(cellStyle);
                    resCellIndex++;
                    break;
                case "MIN":
                    MinIndexes.add(cellIndex);
                    resCell = resRow.createCell(resCellIndex);
                    resCell.setCellValue("MIN");
                    resCell.setCellStyle(cellStyle);
                    resCellIndex++;
                    break;
                case "MAX":
                    MaxIndexes.add(cellIndex);
                    resCell = resRow.createCell(resCellIndex);
                    resCell.setCellValue("MAX");
                    resCell.setCellStyle(cellStyle);
                    resCellIndex++;
                    break;
                case "CONC":
                    ConcIndexes.add(cellIndex);
                    resCell = resRow.createCell(resCellIndex);
                    resCell.setCellValue("CONC");
                    resCell.setCellStyle(cellStyle);
                    resCellIndex++;
                    break;
            }
            cell = row.getCell(++cellIndex);
        }
    }
}
